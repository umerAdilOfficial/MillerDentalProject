def predict_patient_return(patient):
    """
    Predicts whether a patient will return based on simple business rules.

    Args:
        patient (dict): Patient data with keys:
            - 'age': int
            - 'previous_visits': int
            - 'symptoms_severity': int (1-5)
            - 'insurance': str ('Yes'/'No')
            - 'visit_reason': str

    Returns:
        int: 1 if predicted to return, 0 otherwise
    """

    # Rule 1: Patients with high symptom severity and multiple previous visits are likely to return
    if patient['symptoms_severity'] >= 4 and patient['previous_visits'] >= 3:
        return 1

    # Rule 2: Younger patients (<30) with insurance are more likely to return
    if patient['age'] < 30 and patient['insurance'].lower() == 'yes':
        return 1

    # Rule 3: Patients with no insurance are less likely to return
    if patient['insurance'].lower() == 'no':
        return 0

    # Default rule: if none of the above, assume no return
    return 0

# Example usage
if __name__ == "__main__":
    new_patient = {
        'age': 56,
        'previous_visits': 1,
        'symptoms_severity': 3,
        'insurance': 'Yes',
        'visit_reason': 'Fever'
    }

    prediction = predict_patient_return(new_patient)
    print("Will the patient return?", "Yes" if prediction == 1 else "No")