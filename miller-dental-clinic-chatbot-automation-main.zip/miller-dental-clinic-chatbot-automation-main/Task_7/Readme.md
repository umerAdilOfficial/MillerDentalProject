# Patient Return Prediction Rule-Based System

This project implements a simple rule-based system to predict whether a patient will return based on specific criteria such as age, gender, and appointment status.

## Features
- Basic rule-based logic for patient return prediction.
- Easy to extend with additional rules and features.

## Usage

1. Ensure you have Python installed (version 3.6+ recommended).

2. Save the Python script provided as `predict_patient_return.py`.

3. (Optional) Create a virtual environment and install dependencies:
```bash
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`
pip install -r requirements.txt