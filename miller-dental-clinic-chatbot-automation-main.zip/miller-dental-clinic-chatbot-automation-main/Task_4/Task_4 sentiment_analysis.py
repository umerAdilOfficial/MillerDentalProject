import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Download the VADER lexicon if you haven't already
nltk.download('vader_lexicon')

def analyze_sentiment(feedback):
    sid = SentimentIntensityAnalyzer()
    scores = sid.polarity_scores(feedback)
    compound = scores['compound']
    if compound >= 0.05:
        return "Positive"
    elif compound <= -0.05:
        return "Negative"
    else:
        return "Neutral"

# Example usage:
feedback = "This website is fantastic!"
result = analyze_sentiment(feedback)
print(f"Feedback sentiment: {result}")