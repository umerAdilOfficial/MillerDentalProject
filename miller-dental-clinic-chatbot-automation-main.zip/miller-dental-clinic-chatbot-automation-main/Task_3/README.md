# Task 3: SMS Reminder System

## Overview
This system automatically sends SMS reminders to patients 24 hours before their appointment at Miller Dental Clinic using email-to-SMS gateways (no Twilio account needed).

## Features
✅ **No extra accounts required** - Uses your Outlook email to send SMS via carrier gateways  
✅ **Multiple patients support** - Reads from CSV file  
✅ **Scheduled reminders** - Runs in background, checks every 5 minutes  
✅ **SMS via Email** - Sends emails to phone@carrier.com (e.g., Verizon)  
✅ **Error handling & logging** - Tracks all activities  
✅ **Carrier support** - Supports major US carriers (Verizon, AT&T, T-Mobile, etc.)  
✅ **Retry mechanism** - Retries on failure  

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Email Credentials
Use the same Outlook credentials as Task_2:
- Update `EMAIL_ADDRESS` and `EMAIL_PASSWORD` in the script with your Outlook details.

### 3. Update Appointments CSV
Ensure `appointments.csv` in Task_2 has a `phone` column with patient phone numbers in international format (e.g., +1234567890).

### 4. Carrier Configuration
The script assumes Verizon by default. To change:
- Update `DEFAULT_CARRIER` in the script (options: verizon, att, tmobile, sprint).
- For multiple carriers, add a `carrier` column to the CSV and modify the script to read it.

### 5. Run the Script
```bash
python Task_3 sms_reminder.py
```

The script will monitor appointments and send SMS reminders 24 hours before each one.

## Notes
- Email-to-SMS may have delays or limits by carriers.
- Works best for US carriers; check your carrier's email domain.
- For production, consider a paid SMS service like Twilio.