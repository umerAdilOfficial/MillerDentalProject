import os
import sqlite3
from datetime import datetime, timedelta
import logging
from apscheduler.schedulers.background import BackgroundScheduler
import smtplib
import time
from dotenv import load_dotenv
# Load environment variables
load_dotenv.load_dotenv()
SENDER_EMAIL = os.getenv('SENDER_EMAIL')
SENDER_PASSWORD = os.getenv('SENDER_PASSWORD')

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')



# Carrier gateways mapping
CARRIER_GATEWAYS = {
    'AT&T': 'txt.att.net',
    'Verizon': 'vtext.com',
    'T-Mobile': 'tmomail.net',
    'Sprint': 'messaging.sprintpcs.com',
    # Add more carriers as needed
}

# Initialize scheduler
scheduler = BackgroundScheduler()

def get_gateway_email(phone_number, carrier):
    gateway = CARRIER_GATEWAYS.get(carrier)
    if gateway:
        return f"{phone_number}@{gateway}"
    else:
        logging.warning(f"Unknown carrier for {phone_number} ({carrier})")
        return None

def send_sms(to_email, patient_name):
    subject = 'Appointment Reminder'
    body = f"Dear {patient_name}, this is a reminder for your appointment in 24 hours."
    message = f"Subject: {subject}\n\n{body}"
    try:
        with smtplib.SMTP('smtp.office365.com', 587) as smtp:
            smtp.starttls()
            smtp.login(SENDER_EMAIL, SENDER_PASSWORD)
            smtp.sendmail(SENDER_EMAIL, to_email, message)
        logging.info(f"Reminder sent to {to_email}")
    except Exception as e:
        logging.error(f"Failed to send SMS to {to_email}: {e}")

def schedule_reminder(appointment_id, appointment_time, patient_name, to_email):
    reminder_time = appointment_time - timedelta(hours=24)
    now = datetime.now()
    if reminder_time > now:
        scheduler.add_job(
            send_sms,
            'date',
            run_date=reminder_time,
            args=[to_email, patient_name],
            id=str(appointment_id)
        )
        logging.info(f"Scheduled reminder for {patient_name} at {reminder_time}")
    else:
        logging.info(f"Reminder time for {patient_name} has already passed; skipping.")

def load_appointments():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY,
            patient_name TEXT NOT NULL,
            phone_number TEXT NOT NULL,
            carrier TEXT NOT NULL,
            appointment_date TEXT NOT NULL
        )
    ''')
    conn.commit()

    cursor.execute('SELECT * FROM appointments')
    appointments = cursor.fetchall()

    for appt in appointments:
        appt_id, name, phone, carrier, date_str = appt
        try:
            appointment_time = datetime.strptime(date_str, '%Y-%m-%d %H:%M')
            to_email = get_gateway_email(phone, carrier)
            if to_email:
                schedule_reminder(appt_id, appointment_time, name, to_email)
        except Exception as e:
            logging.error(f"Error processing appointment {appt_id}: {e}")

    conn.close()

def main():
    load_appointments()
    scheduler.start()
    logging.info("Scheduler started. Waiting for scheduled reminders...")
    try:
        while True:
            time.sleep(60)
    except (KeyboardInterrupt, SystemExit):
        logging.info("Shutting down...")
        scheduler.shutdown()

if __name__ == "__main__":
    main()