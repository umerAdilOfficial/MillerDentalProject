# Task 2: Email Reminder System

## Overview
This system automatically sends email reminders to patients 24 hours before their appointment at Miller Dental Clinic.

## Features
✅ **Secure credential management** - Uses environment variables  
✅ **Multiple patients support** - Reads from CSV file  
✅ **Scheduled reminders** - Runs in background, checks every 5 minutes  
✅ **Professional HTML emails** - Formatted templates  
✅ **Error handling & logging** - Tracks all activities  
✅ **Email validation** - Validates email format  
✅ **Retry mechanism** - Retries up to 3 times on failure  

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Email Credentials (Outlook)
Set these environment variables on your system:

**Windows (PowerShell):**
```powershell
$env:EMAIL_ADDRESS = "your-email@outlook.com"
$env:EMAIL_PASSWORD = "your-outlook-password"
$env:SMTP_SERVER = "smtp-mail.outlook.com"
$env:SMTP_PORT = "587"
$env:CLINIC_PHONE = "(123) 456-7890"
$env:CLINIC_EMAIL = "clinic@example.com"
```

**Windows (Command Prompt):**
```cmd
setx EMAIL_ADDRESS "your-email@outlook.com"
setx EMAIL_PASSWORD "your-outlook-password"
setx SMTP_SERVER "smtp-mail.outlook.com"
setx SMTP_PORT "587"
setx CLINIC_PHONE "(123) 456-7890"
setx CLINIC_EMAIL "clinic@example.com"
```

**Linux/Mac:**
```bash
export EMAIL_ADDRESS="your-email@outlook.com"
export EMAIL_PASSWORD="your-outlook-password"
export SMTP_SERVER="smtp-mail.outlook.com"
export SMTP_PORT="587"
export CLINIC_PHONE="(123) 456-7890"
export CLINIC_EMAIL="clinic@example.com"
```

### 3. Prepare Appointments CSV
Create an `appointments.csv` file with the following format:

```csv
patient_name,email,appointment_datetime,doctor_name
John Doe,john@example.com,2026-04-19 14:00,Dr. Smith
Jane Smith,jane@example.com,2026-04-19 15:30,Dr. Johnson
```

**Required columns:**
- `patient_name`: Full name of patient
- `email`: Patient's email address (validated)
- `appointment_datetime`: In format YYYY-MM-DD HH:MM (24-hour)
- `doctor_name`: Name of dentist/doctor

### 4. Run the System
```bash
python "Task_2 email_reminder.py"
```

The system will:
1. Load appointments from CSV
2. Check every 5 minutes for appointments within 24 hours
3. Send reminder emails to patients
4. Log all activities to `email_reminders.log`

## Outlook Setup (Recommended)

**Using your Outlook account:**
1. Use your Outlook email address: `your-email@outlook.com`
2. Use your Outlook password (your regular password—no special setup needed)
3. SMTP Server: `smtp-mail.outlook.com`
4. Port: `587`

That's it! No App Passwords needed.

**Supported Outlook domains:**
- outlook.com
- outlook.live.com
- hotmail.com

## Email Providers

The system works with any SMTP email provider:
- **Outlook** (Recommended): smtp-mail.outlook.com:587
- **Gmail**: smtp.gmail.com:587 (requires App Password)
- **Yahoo**: smtp.mail.yahoo.com:587

## CSV Format Example

```
patient_name,email,appointment_datetime,doctor_name
John Doe,john.doe@email.com,2026-04-20 09:00,Dr. Smith
Jane Smith,jane.smith@email.com,2026-04-20 10:30,Dr. Johnson
Bob Wilson,bob.wilson@email.com,2026-04-20 14:00,Dr. Brown
```

## Logs
All activities are logged to `email_reminders.log`:
- Successful email sends
- Failed attempts with reasons
- Scheduling information
- Errors and warnings

## Troubleshooting

**Error: "SMTP authentication failed"**
- Check EMAIL_ADDRESS and EMAIL_PASSWORD are correct
- Use Gmail App Password, not your regular password

**Error: "Invalid email address"**
- Check the CSV file for typos in email addresses
- Email format should be: name@domain.com

**Reminders not sending**
- Ensure appointments CSV is in the same folder
- Check that appointment times are set correctly
- Review `email_reminders.log` for details

## Production Deployment

For production, consider:
1. Running as a scheduled service/daemon
2. Using a database instead of CSV
3. Adding email templates with branding
4. Setting up email confirmation tracking
5. Adding appointment rescheduling links in emails

