import csv
import smtplib
import time
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables from .env file

# Access credentials from environment variables
OUTLOOK_EMAIL = os.getenv('OUTLOOK_EMAIL')
OUTLOOK_PASSWORD = os.getenv('OUTLOOK_PASSWORD')

# Path to your CSV file
CSV_FILE = 'appointments.csv'

def send_email(to_email, patient_name):
    subject = "Appointment Reminder"
    body = f"Dear {patient_name},\n\nThis is a reminder for your appointment scheduled in 24 hours.\n\nBest regards,\nYour Clinic"
    message = f"Subject: {subject}\n\n{body}"

    try:
        with smtplib.SMTP('smtp.office365.com', 587) as server:
            server.starttls()
            server.login(OUTLOOK_EMAIL, OUTLOOK_PASSWORD)
            server.sendmail(OUTLOOK_EMAIL, to_email, message)
        print(f"Reminder email sent to {to_email}")
    except Exception as e:
        print(f"Failed to send email to {to_email}: {e}")

def schedule_emails():
    with open(CSV_FILE, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            email = row['email']
            patient_name = row['patient_name']
            appointment_time_str = row['appointment_datetime']
            try:
                appointment_time = datetime.strptime(appointment_time_str, '%Y-%m-%d %H:%M')
            except ValueError:
                print(f"Invalid date format for {patient_name}: {appointment_time_str}")
                continue

            reminder_time = appointment_time - timedelta(hours=24)
            current_time = datetime.now()

            wait_seconds = (reminder_time - current_time).total_seconds()

            if wait_seconds > 0:
                print(f"Scheduling reminder for {patient_name} at {reminder_time}")
                time.sleep(wait_seconds)
                send_email(email, patient_name)
            elif 0 <= (appointment_time - current_time).total_seconds() <= 86400:
                # If appointment is within 24 hours and reminder time has passed
                print(f"Sending immediate reminder to {patient_name}")
                send_email(email, patient_name)
            else:
                print(f"No reminder scheduled for {patient_name} (appointment in past or too far in future).")

if __name__ == "__main__":
    schedule_emails()