import os
import re
import logging
from flask import Flask, request, jsonify
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__)

# Configure logging
logging.basicConfig(filename='auto_reply.log', level=logging.INFO,
                    format='%(asctime)s %(levelname)s:%(message)s')

# Environment variables for sensitive info
EMAIL_HOST = os.getenv('EMAIL_HOST')  # e.g., smtp.gmail.com
EMAIL_PORT = int(os.getenv('EMAIL_PORT', 587))
EMAIL_USER = os.getenv('EMAIL_USER')
EMAIL_PASS = os.getenv('EMAIL_PASS')
REPLY_SUBJECT = "Thank you for contacting us!"

# Email validation regex
EMAIL_REGEX = r"[^@]+@[^@]+\.[^@]+"

def is_valid_email(email):
    return re.match(EMAIL_REGEX, email)

def send_email(to_email, subject, body):
    try:
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = EMAIL_USER
        msg['To'] = to_email

        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
            server.starttls()
            server.login(EMAIL_USER, EMAIL_PASS)
            server.sendmail(EMAIL_USER, to_email, msg.as_string())

        logging.info(f"Auto-reply sent to {to_email}")
        return True
    except Exception as e:
        logging.error(f"Failed to send email to {to_email}: {e}")
        return False

@app.route('/contact', methods=['POST'])
def contact():
    data = request.json
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')

    # Validate inputs
    if not email or not is_valid_email(email):
        return jsonify({'status': 'error', 'message': 'Invalid email address'}), 400

    # Compose reply
    reply_body = f"Dear {name or 'Customer'},\n\nThank you for reaching out. We will get back to you shortly.\n\nBest regards,\nYour Dental Clinic"

    # Send auto-reply
    success = send_email(email, REPLY_SUBJECT, reply_body)

    # Log the contact form submission
    logging.info(f"Received contact form from {name} ({email}): {message}")

    if success:
        return jsonify({'status': 'success', 'message': 'Auto-reply sent'}), 200
    else:
        return jsonify({'status': 'error', 'message': 'Failed to send auto-reply'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)