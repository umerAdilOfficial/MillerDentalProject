import csv
import os
import logging
from pathlib import Path
from difflib import SequenceMatcher

# Configuration
CONFIG = {
    'clinic_name': 'Miller Dental Clinic',
    'clinic_location': 'Your Clinic Address Here',
    'clinic_phone': 'Your Phone Number',
    'csv_filename': 'medical_questions.csv',
    'log_filename': 'chatbot.log',
    'similarity_threshold': 0.6  # Minimum similarity score for matching
}

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(CONFIG['log_filename']),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Knowledge base data
KNOWLEDGE_BASE = [
    {"question": "What are the symptoms of a cavity?", "answer": "Symptoms include tooth sensitivity, pain, and visible holes in the teeth."},
    {"question": "How often should I get a dental checkup?", "answer": "It is recommended to have a dental checkup every 6 months."},
    {"question": "What is teeth whitening?", "answer": "Teeth whitening is a cosmetic procedure that lightens the color of your teeth."},
    {"question": "How can I prevent gum disease?", "answer": "Maintain good oral hygiene by brushing twice daily, flossing regularly, and visiting your dentist."},
    {"question": "What should I do if I have a toothache?", "answer": "Rinse your mouth with warm water, avoid very hot or cold foods, and see a dentist promptly."},
    {"question": "How long does teeth whitening take?", "answer": "The procedure usually takes about 45 minutes, depending on the method used."},
    {"question": "Where is the clinic located?", "answer": f"Our clinic is located at {CONFIG['clinic_location']}."},
    {"question": "What is your phone number?", "answer": f"You can reach us at {CONFIG['clinic_phone']}."}
]

def initialize_csv():
    """Initialize the CSV file with knowledge base if it doesn't exist."""
    csv_path = Path(CONFIG['csv_filename'])
    
    if csv_path.exists():
        logger.info(f"CSV file '{CONFIG['csv_filename']}' already exists.")
        return
    
    try:
        with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['question', 'answer']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in KNOWLEDGE_BASE:
                writer.writerow(row)
        logger.info(f"CSV file '{CONFIG['csv_filename']}' created successfully with {len(KNOWLEDGE_BASE)} entries.")
    except IOError as e:
        logger.error(f"Error creating CSV file: {e}")
        raise

def load_knowledge_base():
    """Load knowledge base from CSV file."""
    csv_path = Path(CONFIG['csv_filename'])
    
    if not csv_path.exists():
        logger.warning(f"CSV file '{CONFIG['csv_filename']}' not found. Using in-memory knowledge base.")
        return KNOWLEDGE_BASE
    
    try:
        data = []
        with open(csv_path, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                data.append(row)
        logger.info(f"Loaded {len(data)} entries from CSV file.")
        return data
    except IOError as e:
        logger.error(f"Error loading CSV file: {e}")
        return KNOWLEDGE_BASE

def calculate_similarity(string1, string2):
    """Calculate similarity score between two strings."""
    return SequenceMatcher(None, string1.lower(), string2.lower()).ratio()

def find_best_match(user_input, knowledge_base):
    """Find the best matching answer using similarity scoring."""
    best_match = None
    best_score = CONFIG['similarity_threshold']
    
    user_input_lower = user_input.lower().strip()
    
    for item in knowledge_base:
        similarity_score = calculate_similarity(user_input_lower, item['question'].lower())
        if similarity_score > best_score:
            best_score = similarity_score
            best_match = item
    
    return best_match

def sanitize_input(user_input):
    """Sanitize and validate user input."""
    if not isinstance(user_input, str):
        return None
    
    sanitized = user_input.strip()
    if len(sanitized) == 0 or len(sanitized) > 500:
        return None
    
    return sanitized

def run_chatbot():
    """Main chatbot loop."""
    try:
        initialize_csv()
        knowledge_base = load_knowledge_base()
        
        print(f"\nWelcome to {CONFIG['clinic_name']} Chatbot!")
        print("Type 'exit' or 'quit' to end the conversation.")
        print("Type 'help' to see available commands.\n")
        
        logger.info("Chatbot started successfully.")
        
        while True:
            try:
                user_input = input("You: ")
                
                # Sanitize input
                sanitized_input = sanitize_input(user_input)
                if sanitized_input is None:
                    print("Bot: Please enter a valid question.\n")
                    continue
                
                # Handle special commands
                if sanitized_input.lower() in ['exit', 'quit']:
                    print("Bot: Thank you for visiting Miller Dental Clinic! Have a great day.")
                    logger.info("Chatbot ended by user.")
                    break
                
                if sanitized_input.lower() == 'help':
                    print("Bot: I can help you with questions about dental care, clinic information, and more. Try asking me anything!")
                    continue
                
                # Find and provide answer
                match = find_best_match(sanitized_input, knowledge_base)
                
                if match:
                    response = match['answer']
                    logger.info(f"User: {sanitized_input} -> Match found: {match['question']}")
                else:
                    response = "I'm sorry, I don't have an answer for that. Please try rephrasing your question or visit our clinic for assistance."
                    logger.warning(f"User: {sanitized_input} -> No suitable match found.")
                
                print(f"Bot: {response}\n")
                
            except KeyboardInterrupt:
                print("\n\nBot: Session interrupted. Thank you for using our service!")
                logger.info("Chatbot interrupted by user.")
                break
            except Exception as e:
                logger.error(f"Error processing user input: {e}")
                print("Bot: An error occurred. Please try again.\n")
    
    except Exception as e:
        logger.error(f"Fatal error in chatbot: {e}")
        print("An error occurred while starting the chatbot. Please check the logs.")

if __name__ == "__main__":
    run_chatbot()