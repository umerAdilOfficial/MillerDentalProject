# Task 1: Dental Clinic Chatbot Setup

## Overview
This module sets up and runs a dental clinic chatbot that answers frequently asked questions about dental health, clinic services, and appointments. The chatbot uses a knowledge base stored in CSV format and provides intelligent response matching.

## Features
✅ **Knowledge Base Management** - Q&A pairs stored in CSV  
✅ **Intelligent Matching** - Uses similarity scoring for better answers  
✅ **Input Validation** - Sanitizes user input  
✅ **Logging System** - Tracks all interactions  
✅ **Graceful Error Handling** - Handles edge cases properly  
✅ **Modular Design** - Well-organized, reusable functions  
✅ **Help Command** - Users can type 'help' for guidance  

## Installation

### 1. No External Dependencies Required
This module uses only Python standard library modules:
- `csv` - For reading/writing knowledge base
- `os` - For file operations
- `logging` - For activity tracking
- `pathlib` - For file path handling
- `difflib` - For similarity matching

### 2. Run the Chatbot
```bash
python "Task_1 chatbot_setup.py"
```

## Configuration

The chatbot uses a CONFIG dictionary for easy customization:

```python
CONFIG = {
    'clinic_name': 'Miller Dental Clinic',
    'clinic_location': 'Your Clinic Address Here',
    'clinic_phone': 'Your Phone Number',
    'csv_filename': 'medical_questions.csv',
    'log_filename': 'chatbot.log',
    'similarity_threshold': 0.6
}
```

**Update these values:**
- `clinic_name` - Your clinic name
- `clinic_location` - Full clinic address
- `clinic_phone` - Contact phone number
- `csv_filename` - Where to store Q&A pairs
- `log_filename` - Activity log file
- `similarity_threshold` - How closely user input must match (0.0-1.0)

## Usage

### Starting the Chatbot
```bash
python "Task_1 chatbot_setup.py"
```

### Commands
- **Ask a question** - Type any question about dental health or clinic services
- **Type `help`** - See available commands
- **Type `exit` or `quit`** - End the conversation

### Example Interaction
```
Welcome to Miller Dental Clinic Chatbot!
Type 'exit' or 'quit' to end the conversation.
Type 'help' to see available commands.

You: What causes cavities?
Bot: Symptoms include tooth sensitivity, pain, and visible holes in the teeth.

You: exit
Bot: Thank you for visiting Miller Dental Clinic! Have a great day.
```

## Knowledge Base (CSV Format)

The chatbot stores Q&A pairs in a CSV file with two columns:

```csv
question,answer
What are the symptoms of a cavity?,Symptoms include tooth sensitivity, pain, and visible holes in the teeth.
How often should I get a dental checkup?,It is recommended to have a dental checkup every 6 months.
What is teeth whitening?,Teeth whitening is a cosmetic procedure that lightens the color of your teeth.
```

### Adding New Q&A Pairs

Edit the `KNOWLEDGE_BASE` in the script or manually add rows to the CSV file:

```python
KNOWLEDGE_BASE = [
    {"question": "Your question here?", "answer": "Your answer here."},
    # Add more Q&A pairs...
]
```

Or edit the CSV directly:
1. Open `medical_questions.csv` in any text editor
2. Add new rows in format: `question,answer`
3. Save the file

## How It Works

### 1. Initialization
- Loads knowledge base from CSV (or creates it if missing)
- Sets up logging to both console and file

### 2. User Interaction
- Accepts user input and sanitizes it
- Validates input length (0-500 characters)

### 3. Smart Matching
- Uses `SequenceMatcher` to calculate similarity score
- Compares user input against all Q&A pairs
- Returns best match if similarity score > threshold (default: 0.6)

### 4. Response
- Provides matching answer if found
- Shows helpful message if no match found

### 5. Logging
- Records all interactions to `chatbot.log`
- Tracks matched questions and unmatched queries
- Useful for analyzing chatbot performance

## Output Files

After running, the chatbot creates:

1. **medical_questions.csv** - Knowledge base with Q&A pairs
2. **chatbot.log** - Activity log with timestamps

Example log output:
```
2026-04-18 19:58:22,784 - INFO - CSV file 'medical_questions.csv' created successfully with 8 entries.
2026-04-18 19:58:22,823 - INFO - Loaded 8 entries from CSV file.
2026-04-18 19:58:22,824 - INFO - Chatbot started successfully.
2026-04-18 19:58:41,145 - INFO - User: What are the symptoms of a cavity? -> Match found
```

## Pre-loaded Questions

The chatbot comes with 8 default Q&A pairs:

1. Symptoms of a cavity
2. Dental checkup frequency
3. Teeth whitening explanation
4. Gum disease prevention
5. Toothache treatment
6. Teeth whitening duration
7. Clinic location
8. Clinic phone number

## Improving Chatbot Accuracy

### Similarity Threshold
- **Lower threshold (0.4-0.5)** - More matches, but may be less relevant
- **Higher threshold (0.7-0.8)** - More strict, fewer false matches

Adjust in CONFIG:
```python
CONFIG['similarity_threshold'] = 0.65
```

### Expanding Knowledge Base
- Add more Q&A pairs to cover common questions
- Use keywords that patients actually search for
- Review logs to see what questions weren't matched

## Troubleshooting

**No responses to questions**
- Check that CSV file exists and has data
- Lower the similarity threshold in CONFIG
- Review chatbot.log for error messages

**CSV file errors**
- Delete corrupted CSV and restart (new one will be created)
- Ensure proper CSV format: question,answer

**Chatbot won't start**
- Check Python version (3.7+)
- Verify file permissions
- Check chatbot.log for errors

## Production Tips

For production deployment:
1. **Expand Knowledge Base** - Add 50+ Q&A pairs
2. **Use Database** - Replace CSV with SQLite/PostgreSQL
3. **Add Analytics** - Track popular questions
4. **Email Integration** - Send responses via email option
5. **Multi-language Support** - Support multiple languages
6. **Backup** - Regular backups of knowledge base
7. **Update Log** - Keep knowledge base up-to-date

## Files Included

- `Task_1 chatbot_setup.py` - Main chatbot script
- `medical_questions.csv` - Knowledge base (auto-created)
- `chatbot.log` - Activity log (auto-created)
- `requirements.txt` - Python dependencies
- `README.md` - This file

