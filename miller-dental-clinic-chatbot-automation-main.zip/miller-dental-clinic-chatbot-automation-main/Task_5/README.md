# Voice Appointment Booking System 🎙️📅

A simple Python project that allows you to book appointments using voice commands on Windows.

---

## 🚀 Features
- Voice recognition to understand user requests
- Text-to-speech responses for interaction
- Stores booked appointments in memory
- Easy to expand and customize

---

## 🛠️ Requirements
- Python 3.x installed on your Windows system
- Necessary Python libraries listed in `requirements.txt`

---

## 📦 Installation

1. Clone or download this repository.
2. Navigate to your project directory in Command Prompt.
3. Install dependencies:

```bash
pip install -r requirements.txt