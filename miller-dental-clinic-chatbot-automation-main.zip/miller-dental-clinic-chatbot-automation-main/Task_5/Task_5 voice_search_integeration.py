import sqlite3
import speech_recognition as sr
import threading
import time

# Database setup and functions
def init_db():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            service TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def add_appointment(name, date, time_slot, service):
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO appointments (name, date, time, service)
        VALUES (?, ?, ?, ?)
    ''', (name, date, time_slot, service))
    conn.commit()
    conn.close()

def list_appointments():
    conn = sqlite3.connect('appointments.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM appointments')
    appointments = cursor.fetchall()
    conn.close()
    return appointments

# Speech recognition with error handling
recognizer = sr.Recognizer()

def listen_command():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        print("Listening for a command...")
        try:
            audio = recognizer.listen(source, timeout=5)
            command = recognizer.recognize_google(audio)
            print(f"Recognized command: {command}")
            return command.lower()
        except sr.WaitTimeoutError:
            print("Listening timed out. Please try again.")
        except sr.UnknownValueError:
            print("Sorry, I did not understand that.")
        except sr.RequestError:
            print("Speech recognition service is unavailable.")
        return ""

# Command processing
def process_command(command):
    if "book appointment" in command:
        # For simplicity, using input prompts; in production, use NLP
        print("Please provide the following details.")
        name = input("Name: ").strip()
        date = input("Date (YYYY-MM-DD): ").strip()
        time_slot = input("Time (HH:MM): ").strip()
        service = input("Service: ").strip()

        # Basic validation
        if not (name and date and time_slot and service):
            print("All fields are required. Please try again.")
            return

        add_appointment(name, date, time_slot, service)
        print(f"Appointment booked for {name} on {date} at {time_slot} for {service}.")

    elif "show appointments" in command or "list appointments" in command:
        appointments = list_appointments()
        if not appointments:
            print("No appointments found.")
        else:
            print("Upcoming Appointments:")
            for appt in appointments:
                print(f"{appt[1]}: {appt[2]} at {appt[3]} for {appt[4]}")
    elif "exit" in command or "quit" in command:
        print("Exiting the system. Goodbye!")
        return True
    else:
        print("Command not recognized. Please try again.")
    return False

# Main loop
def main():
    init_db()
    print("Voice Appointment Booking System Initialized.")
    print("Say 'book appointment' to create a new appointment.")
    print("Say 'show appointments' to list all.")
    print("Say 'exit' to quit.")
    while True:
        command = listen_command()
        if command:
            should_exit = process_command(command)
            if should_exit:
                break
        time.sleep(1)  # Small delay to prevent high CPU usage

if __name__ == "__main__":
    main()